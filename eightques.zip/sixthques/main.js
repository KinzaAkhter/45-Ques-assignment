"use strict";
//6.store a person's name and include some whitespace characters at the beginning and end of the name
let person3 = "\t\n Myra\t\n";
console.log(person3);
let per = person3.trim(); //trim k func k through original string mai jo \t aur\n h wo trim hogya.
console.log(per);
