"use strict";
/*If you have not received an array index error yet produce an error in your program
then correct the given error
 */
let array = ['a', 'b', 'c'];
//producing array error
//console.log(array[5]);
//correcting error
console.log(array[2]);
