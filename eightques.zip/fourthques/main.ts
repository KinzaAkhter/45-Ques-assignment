//4.find the famous quote of your fav person and print the quote and name of its author
console.log(`Albert Einstein once said,"A person who never made a mistake never tried anything new"`);