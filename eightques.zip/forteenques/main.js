"use strict";
//14. guest list. if your could invite anyone living or deceased to dinner who would you invite
//make a list of atleast 3 people who would u like to invite then use your list to print a messageto each person
const guestList = ["Ali", "Fatima", "Kinza", "Yusha"];
guestList.map((i) => {
    console.log(`${i} You are invited for dinner on Sunday`);
});
