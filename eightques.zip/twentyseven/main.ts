// First version 
 /*
let alien_color = "green";
if (alien_color === "green"){
    console.log("Version : 1 Alien color is green player earned 5 points");

}
else if(alien_color === "yellow"){
    console.log("Version : 1 Alien color is yelow player earned 10 points");

}
else if(alien_color === "blue"){
    console.log("Version : 1 Alien color is blue player earned 15 points");

}
*/

// Second version 
 /*
let alien_color = "yellow";
if (alien_color === "green"){
    console.log("Version : 2 Alien color is green player earned 5 points");

}
else if(alien_color === "yellow"){
    console.log("Version : 2 Alien color is yelow player earned 10 points");

}
else if(alien_color === "blue"){
    console.log("Version : 2 Alien color is blue player earned 15 points");

}
*/

// Third version 
 
let alien_color = "blue";
if (alien_color === "green"){
    console.log("Version : 3 Alien color is green player earned 5 points");

}
else if(alien_color === "yellow"){
    console.log("Version : 3 Alien color is yelow player earned 10 points");

}
else if(alien_color === "blue"){
    console.log("Version : 3 Alien color is blue player earned 15 points");

}