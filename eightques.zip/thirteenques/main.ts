//think of your fav mode of transportation and make a list to store several examples use your list to print a series of statement "I would like to own a Honda mo"
let transportation : string[] = ["Audi","Honda City","Suzuki"]
transportation.map((items)=>console.log(`I would like to own a ${items}.`))