"use strict";
//10. add comments to any two of your programs
// Name:Kinza Akhter
//Program: Hello Kinza
console.log("Hello Kinza");
