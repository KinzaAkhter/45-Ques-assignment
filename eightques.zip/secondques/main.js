"use strict";
//2.personal message: store a person's name ina variable & print a message to that person
let person = "Kinza";
let msg = "would you like to learn some Python today? ";
console.log("Hello " + person + " " + msg);
