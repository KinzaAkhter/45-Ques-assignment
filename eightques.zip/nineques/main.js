"use strict";
//9. store your fav no in a variable then using the var create a message that reveals your fav num print msg
let fav_num = 5;
let msgs = "My favourite number is: " + fav_num;
console.log(msgs);
