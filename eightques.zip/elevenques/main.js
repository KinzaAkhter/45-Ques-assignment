"use strict";
//11. Store the name of few of yourfriends in an array. print each person's name by accessing each element in list at a time
let friendsArr = ["Amna", "Rameen", "Sumbul", "Sheeza"];
for (let i = 0; i < friendsArr.length; i++) {
    console.log(friendsArr[i]);
}
