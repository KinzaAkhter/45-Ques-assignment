"use strict";
//7. perform add sub multiply and division
let no1 = 23 + 2;
console.log(no1);
let no2 = 22 - 2;
console.log(no2);
let no3 = 5 * 2;
console.log(no3);
let no4 = 15 % 5;
console.log(no4);
