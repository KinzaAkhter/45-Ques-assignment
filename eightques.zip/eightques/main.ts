//8. you should create 4 lines that looks like console.log(5+3); out should be 4 times 8
console.log(5+3);
console.log(6+2);
console.log(4*2);
console.log(5+3);