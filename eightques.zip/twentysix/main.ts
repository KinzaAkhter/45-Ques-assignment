//First version
/*
let alien_color = "green";
if( alien_color === "green"){
    console.log("the player just earned 5 points for shooting the alien");
}

else{
    console.log("Alien color is not green, player earned 10 points");
}
*/


//Second version
let alien_color = "red";
if( alien_color === "green"){
    console.log("the player just earned 5 points for shooting the alien");
}

else{
    console.log("Alien color is not green, player earned 10 points");
}
