"use strict";
//20
let fav_nature = ["mountain", "lake", "ponds", "kang"];
fav_nature.map((a) => {
    console.log(a);
});
