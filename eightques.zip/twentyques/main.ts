//20
let fav_nature: string[]=["mountain","lake","ponds","kang"];
fav_nature.map((a)=>{
    console.log(a);
}
)
