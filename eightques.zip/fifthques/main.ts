//5.repeat 4 but store famous person name and message in variable

let famous_per="Albert Einstein";
let msg1="A person who never made a mistake never tried anything new";
console.log(`${famous_per} once said, ${msg1}`);
